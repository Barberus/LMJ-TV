**You are now Finished**

You may further customize your settings by editing channel numbers, etc.

If you require further help, check out
[Tvheadend.org](http://tvheadend.org) or chat to us on
[IRC](https://web.libera.chat/?nick=tvhhelp|?#hts).

Thank you for using Tvheadend (and don't forget to
[donate](http://tvheadend.org/projects/tvheadend/wiki/Donate))! :)
