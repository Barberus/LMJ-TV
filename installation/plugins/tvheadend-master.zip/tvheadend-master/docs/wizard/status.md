**Scanning**

Tvheadend is now scanning for available services. Please wait until the
scan completes..
