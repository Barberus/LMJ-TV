**Welcome to Tvheadend, Your TV Streaming Server and Video Recorder**

Let's start by configuring the basic language settings. Please select 
the default user interface and EPG language(s).

* This wizard is optional, and can be cancelled at any time, but
recommended for new users.
* Running this wizard on existing configurations is NOT a good idea as
it may lead to confusion, misconfiguration and unexpected features! ;)
* The wizard will restart and reload the interface in your chosen
language, unfortunately not all translations are available/complete.
* If you get stuck at any point and need a little more information, 
press [Help].


