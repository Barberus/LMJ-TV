**Map Services to Channels**

In order for your frontend client(s) (such as Kodi, Movian, and similar)
to see/play channels, you must first map discovered services to
channels. If you would like Tvheadend to do this for you, check the
'Map all services' option below.

**You can skip this step (do not check 'Map all services') and
map services to channels manually.**
