:

Option                         | Description
-------------------------------|------------
**All (Streaming plus DVR)**   | Allow access to all streaming options (including DVR functionality).
**Streaming**                  | Limit access to streaming only (no DVR functionality).
**DVR**                        | Limit access to DVR functionality only.
