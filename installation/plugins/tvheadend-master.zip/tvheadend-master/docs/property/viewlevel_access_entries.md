:

Option                  | Description
------------------------|------------
**Default**             | Use the default view level value as set in [Base Config](class/config).
**Basic**               | Display the most commonly used tabs/items.
**Advanced**            | Display the more advanced tabs/items.
**Expert**              | Show all tabs/items.
