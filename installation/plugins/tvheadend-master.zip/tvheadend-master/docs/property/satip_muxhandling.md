:

Option                  | Description
------------------------|------------------------------------------
**Auto**                | Keep the mux if it doesn't already exist.
**Keep**                | Always keep the mux regardless of whether it exists or not.
**Reject**              | Always reject.
**Reject exact match**  | Always reject but allow partial match.  
