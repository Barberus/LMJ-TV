:

Option                           | Description
---------------------------------|------------
**All**                          | Include all information.
**Basic**                        | Limited information for low memory devices.

This setting can be overridden on a per-user basis, see [Access Entries](class/access).
