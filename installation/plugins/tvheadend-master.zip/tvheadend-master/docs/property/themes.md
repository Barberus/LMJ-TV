:

Option           | Description
-----------------|------------
**Blue**         | Use the (default) blue theme.
**Gray**         | Use the gray theme.
**Access**       | Use the high contrast accessibility theme.

This setting can be overridden on a per-user basis, see [Access Entries](class/access).
