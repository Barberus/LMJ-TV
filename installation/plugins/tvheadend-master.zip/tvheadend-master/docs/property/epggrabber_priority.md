:

Only OTA EIT and PSIP (ATSC) grabbers are enabled by default. 
Also note that **EPG data isn't merged**, so be sure to 
give the highest priority to the grabber that provides you with the 
best data available.

