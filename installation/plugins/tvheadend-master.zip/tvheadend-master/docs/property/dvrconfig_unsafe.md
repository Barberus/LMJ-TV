Note, you may have to disable this option for certain languages/charsets - Hebrew, etc. 
