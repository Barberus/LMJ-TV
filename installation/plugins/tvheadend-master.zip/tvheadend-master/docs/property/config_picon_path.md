This can be named however you wish, as either a local (file://) or 
remote (http://) location - however, remember that it’s pointing to a 
directory as the picon names are automatically generated from the 
service parameters frequency, orbital position (required), etc.

Example: `file:///home/hts/picons`
