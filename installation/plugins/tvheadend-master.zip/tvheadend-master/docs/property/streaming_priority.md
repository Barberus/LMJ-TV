:

Streaming priority is like the *Priority* setting (above) but only 
applies when streaming over HTTP or HTSP. If no streaming priority value 
is set (0) the *Priority* value is used instead.
