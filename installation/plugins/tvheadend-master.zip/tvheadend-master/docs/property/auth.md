:

Option      | Description
------------|-------------
Enable      | Enable persistent authentication.
Reset       | Revoke the code and generate a new one. 
