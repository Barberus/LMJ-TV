:

Option                           | Description
---------------------------------|------------
**All**                          | Include all information.
**Basic**                        | Limited information for low memory devices.
**Basic Alternative (No Hash)**  | Limited information for low memory devices that don't correctly process tv channel names.

This setting can be overridden on a per-user basis, see [Access Entries](class/access).
