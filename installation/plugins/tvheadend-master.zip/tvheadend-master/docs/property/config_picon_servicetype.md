:

The *Picon path* (above) must be set to generate the filenames. 
Also note that changing the scheme will not update existing icons, you must 
use the *[Reset Icons]* button in the [Channels](class/channel) tab
to re-generate them.

Scheme                        | Description
------------------------------|------------
**Standard**                  | Choose this if your picon pack uses the standard naming scheme, e.g "1_0_19_xxxx".
**force service type to 1**   | Choose this if your picon pack has icons that start with "1_0_1_xxxx".
