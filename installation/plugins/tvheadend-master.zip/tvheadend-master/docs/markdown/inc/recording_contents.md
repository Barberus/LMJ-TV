Contents                                              | Description
------------------------------------------------------|-------------
[Overview](#overview)                                 | Overview of the tab
[Digital Video Recorder Profiles](class/dvrconfig)    | DVR profiles and related settings
[Timeshift](class/timeshift)                          | Timeshift settings
[Items/Properties](#items)                            | Tab specific items and properties
