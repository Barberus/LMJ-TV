Contents                               | Description
---------------------------------------|------------------------
[Overview](#overview)                  | Tab overview
[Items/Properties](#items)             | Items and Properties
[Channels](class/channel)              | Channel management
[Channel Tags](class/channeltag)       | Channel tagging management
[Bouquets](class/bouquet)              | Provider-based channel grouping and ordering
[EPG Grabber Channels](class/epggrab_channel)  | EPG data sources used by channels
[EPG Grabber](class/epggrab)            | EPG grabber configuration
[EPG Grabber Modules](class/epggrab_mod)  | EPG grabber module management




