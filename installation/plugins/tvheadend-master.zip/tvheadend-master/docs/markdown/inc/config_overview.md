## Overview

This tab is where you configure many of the server features of Tvheadend.