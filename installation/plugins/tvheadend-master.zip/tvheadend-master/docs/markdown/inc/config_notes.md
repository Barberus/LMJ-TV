### Notes

* The out-of-the-box default settings should suit most set-ups, you should rarely need to change the them.
* Changing some of these settings **may** cause unexpected results, you have been warned!\n