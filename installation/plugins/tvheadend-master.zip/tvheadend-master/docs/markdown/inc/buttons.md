Previous versions of this documentation had buttons tables
everywhere, to make the buttons - and their function/description -
easier to find, they've all been moved to a single table in the
[Introduction](introduction) (*Using the Interface*).

> Many of the buttons have tool-tips giving you a hint as to their
function. If you don't see any, you may need to enable them in
**Configuration -> General -> Base**.
