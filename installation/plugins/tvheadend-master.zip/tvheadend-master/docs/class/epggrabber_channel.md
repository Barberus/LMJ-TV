<tvh_include>inc/channels_contents</tvh_include>

---

## Overview 

This tab displays EPG data used by channels.

!['EPG Grabber Channels Tab'](static/img/doc/channel/grabber_channels_tab.png)

---

## Buttons

<tvh_include>inc/buttons</tvh_include>

---
