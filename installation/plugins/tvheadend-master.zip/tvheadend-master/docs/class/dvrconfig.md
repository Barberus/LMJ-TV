<tvh_include>inc/recording_contents</tvh_include>

---

## Overview

This tab is used to configure operation of the Digital Video Recorder.
It is not used for scheduling or administration of individual
recordings.

!['Digital Video Recorder Profiles' Tab 1](static/img/doc/recordings/dvrprofiles.png)

---

## Buttons

<tvh_include>inc/buttons</tvh_include>

---
