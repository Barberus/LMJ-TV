<tvh_include>inc/recording_contents</tvh_include>

---

## Overview

This tab is used to configure timeshift properties.

!['Timeshift Tab'](static/img/doc/recordings/timeshift.png)

---

## Buttons

<tvh_include>inc/buttons</tvh_include>

---
