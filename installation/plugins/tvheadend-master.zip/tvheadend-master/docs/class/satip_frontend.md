<tvh_include>inc/linuxdvb_contents</tvh_include>

---

## Overview

This panel displays all available SAT>IP 
DVB-T/DVB-S/DVB-C/ATSC-T/ATSC-C frontend parameters.

<tvh_include>inc/dvbinputs_table</tvh_include>

---

## Buttons

<tvh_include>inc/buttons</tvh_include>

---

## Device Types and Configuration

<tvh_include>inc/dvbinputs_type_table</tvh_include>

---