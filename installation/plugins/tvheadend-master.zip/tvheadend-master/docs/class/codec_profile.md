<tvh_include>inc/stream_contents</tvh_include>

---

## Overview

This tab allows you to manage the codec settings used by stream profiles. 

!['Stream Profiles'](static/img/doc/stream/codec_profiles_tab.png)

---

## Buttons

<tvh_include>inc/buttons</tvh_include>

---
