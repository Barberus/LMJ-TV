<tvh_include>inc/channels_contents</tvh_include>

---

## Overview

This tab is used to configure the Electronic Program Guide (EPG) 
[grabbing](class/epggrab_mod) capabilities.

!['EPG Grabber Configuration'](static/img/doc/channel/epgconf_tab.png)

---

## Buttons

<tvh_include>inc/buttons</tvh_include>

---
