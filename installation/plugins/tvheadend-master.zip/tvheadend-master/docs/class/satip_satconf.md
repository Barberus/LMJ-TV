<tvh_include>inc/linuxdvb_contents</tvh_include>

---

## Overview

This panel lists all the available satellite (DVB-S/ISDB-S) configuration 
parameters.

<tvh_include>inc/dvbinputs_table</tvh_include>

---

## Buttons

<tvh_include>inc/buttons</tvh_include>

---

## Device Types and Configuration

<tvh_include>inc/dvbinputs_type_table</tvh_include>

---