<tvh_include>inc/config_contents</tvh_include>

---

<tvh_include>inc/config_overview</tvh_include>

!['General Base'](static/img/doc/config/base.png)

<tvh_include>inc/config_notes</tvh_include>

---

## Buttons

<tvh_include>inc/buttons</tvh_include>

---
