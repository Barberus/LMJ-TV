#pragma once

htsmsg_t *parse_m3u(char *data, const char *charset, const char *url);
