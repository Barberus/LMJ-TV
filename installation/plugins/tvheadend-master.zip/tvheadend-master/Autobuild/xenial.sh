DEBDIST=xenial
source Autobuild/debian.sh
