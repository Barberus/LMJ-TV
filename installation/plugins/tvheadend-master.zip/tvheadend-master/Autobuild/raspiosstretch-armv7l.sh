source Autobuild/armv7l.sh
DEBDIST=raspbianstretch
source Autobuild/debian.sh
