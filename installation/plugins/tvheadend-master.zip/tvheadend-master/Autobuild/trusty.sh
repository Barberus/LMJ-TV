AUTOBUILD_CONFIGURE_EXTRA="${AUTOBUILD_CONFIGURE_EXTRA:-} --nowerror"
DEBDIST=trusty
source Autobuild/debian.sh
