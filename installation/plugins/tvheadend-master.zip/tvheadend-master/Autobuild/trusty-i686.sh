source Autobuild/i686.sh
source Autobuild/trusty.sh
