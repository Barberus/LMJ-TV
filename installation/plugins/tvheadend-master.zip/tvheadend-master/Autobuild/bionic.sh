DEBDIST=bionic
source Autobuild/debian.sh
