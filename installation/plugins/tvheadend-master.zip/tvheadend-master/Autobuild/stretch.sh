DEBDIST=stretch
source Autobuild/debian.sh
