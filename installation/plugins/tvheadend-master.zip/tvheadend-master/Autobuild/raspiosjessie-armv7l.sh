source Autobuild/armv7l.sh
DEBDIST=raspbianjessie
source Autobuild/debian.sh
