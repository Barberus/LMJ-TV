DEBDIST=sid
source Autobuild/debian.sh
