source Autobuild/armv7l.sh
source Autobuild/bionic.sh
