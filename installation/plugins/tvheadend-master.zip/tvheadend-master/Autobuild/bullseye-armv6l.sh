AUTOBUILD_CONFIGURE_EXTRA="${AUTOBUILD_CONFIGURE_EXTRA:-} --disable-libx265_static --disable-libx265"
source Autobuild/armv6l.sh
source Autobuild/bullseye.sh
