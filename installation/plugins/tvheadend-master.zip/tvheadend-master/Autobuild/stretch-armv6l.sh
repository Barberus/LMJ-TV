source Autobuild/armv6l.sh
source Autobuild/stretch.sh
