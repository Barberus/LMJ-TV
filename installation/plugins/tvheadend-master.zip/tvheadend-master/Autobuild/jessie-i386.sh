source Autobuild/i386.sh
source Autobuild/jessie.sh
