DEBDIST=bookworm
source Autobuild/debian.sh
