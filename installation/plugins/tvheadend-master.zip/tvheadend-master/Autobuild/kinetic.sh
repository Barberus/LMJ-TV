DEBDIST=kinetic
source Autobuild/debian.sh
