AUTOBUILD_CONFIGURE_EXTRA="${AUTOBUILD_CONFIGURE_EXTRA:-} --disable-libx265_static --disable-libx265 --nowerror"
source Autobuild/armv6l.sh
source Autobuild/jessie.sh
