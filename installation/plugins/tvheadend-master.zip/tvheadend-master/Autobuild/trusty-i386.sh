source Autobuild/i386.sh
source Autobuild/trusty.sh
