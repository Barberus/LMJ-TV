AUTOBUILD_CONFIGURE_EXTRA="${AUTOBUILD_CONFIGURE_EXTRA:-} --arch=arm64 --disable-libtheora_static --disable-libtheora"
